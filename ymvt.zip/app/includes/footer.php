</main>

<footer class="bg-blue-600 text-white p-4 text-center mt-8">
    <p>&copy; <?= date("Y") ?> YMt</p>
</footer>

<!-- script src="/assets/js/scripts.js"></script -->
</body>
</html>
